/* dnsmasq is Copyright (c) 2000 Simon Kelley

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 dated June, 1991.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
*/

/* See RFC1035 for details of the protocol this code talks. */


#include <arpa/nameser.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdio.h>
#include <netdb.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ctype.h>
#include <signal.h>
#include <syslog.h>

#define VERSION "0.4"

static int process_request(HEADER *header, unsigned char *limit);
static void do_reverse_lookup(HEADER *header, char *name, unsigned char *namep,
			      unsigned char *limit, unsigned char **anspp);
static void do_forward_lookup(HEADER *header, char *name, unsigned char *namep,
			      unsigned char *limit, unsigned char **anspp);
static void do_mx_lookup(HEADER *header, char *name, unsigned char *namep,
			 unsigned char *limit, unsigned char **anspp);
static void multiplex(void);


static char *mxname;
static int port;

int main (int argc, char **argv)
{
  char option;
  int i;

  mxname = NULL;
  port = NAMESERVER_PORT;
  opterr = 0;

  while (1)
    {
      option = getopt(argc, argv, "vm:p:");
      
      if (option == 'v')
	{
	  fprintf(stderr, "dnsmasq version %s\n", VERSION);
	  exit(0);
	}

      if (option == 'm')
	{
	  mxname = malloc(strlen(optarg)+1);
	  strcpy(mxname, optarg);
	}

      if (option == 'p')
	port = atoi(optarg);
      
      if (option == '?')
	{ 
	  fprintf(stderr, "Usage: dnsmasq -v -p <port> -m <mxhost>\n");
	  exit(0);
	}
      
      if (option == -1)
	break;
    }

  /* The following code "daemonizes" the process. See Stevens section 12.4 */
  
  if (fork() != 0 )
    exit(0);

  setsid();
  signal(SIGHUP, SIG_IGN);

  if (fork() != 0)
    exit(0);

  chdir("/");
  umask(0);

  for (i=0; i<64; i++)
    close(i);
  
  openlog("dnsmasq", LOG_PID, LOG_DAEMON);

  syslog(LOG_INFO, "started");
  if (mxname)
    syslog(LOG_INFO, "serving MX record for mailhost %s", mxname);
  
  multiplex();

  return 0;
}

static void multiplex()
{
  int udpfd, listenfd, confd;
  struct sockaddr_in nsaddr, udpaddr, tcpaddr;
  fd_set rset, wset;
  socklen_t udplen, tcplen;
  /* Size: we check after adding each record, so there must be 
     memory for the largest packet, and the largest record */
  char packet[PACKETSZ+MAXDNAME+RRFIXEDSZ];
  u_int16_t reqsize, repsize;
  int repmax;
  char *tcppacket, *readp, *writep;
  enum { ACCEPT, READL0, READL1, READ, WRITEL0, WRITEL1, WRITE } state;

  udpfd = socket(AF_INET, SOCK_DGRAM, 0);
  listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if ((udpfd == -1) || (listenfd == -1))
    {
      syslog(LOG_ERR,"cannot create socket: %m");
      exit(1);
    }

  bzero(&nsaddr, sizeof(nsaddr));
  nsaddr.sin_family = AF_INET;
  nsaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  nsaddr.sin_port = htons(port);

  if (bind(udpfd, (struct sockaddr *) &nsaddr, sizeof(nsaddr)) ||
      bind(listenfd, (struct sockaddr *) &nsaddr, sizeof(nsaddr)) ||
      listen(listenfd, 5))
    {
      syslog(LOG_ERR, "bind failed: %m");
      exit(1);
    }

  state = ACCEPT;
  while (1)
    {
      int maxfd = udpfd;
      
      FD_ZERO(&rset);
      FD_ZERO(&wset);
      FD_SET(udpfd, &rset);
      
      switch (state)
	{
	case ACCEPT:
      	  FD_SET(listenfd, &rset);
	  if (listenfd > maxfd)
	    maxfd = listenfd;
	  break;
	case READL0:
	case READL1:
	case READ:
	  FD_SET(confd, &rset);
	  if (confd > maxfd)
	    maxfd = confd;
	  break;
	case WRITEL0:
	case WRITEL1:
	case WRITE:
	  FD_SET(confd, &wset);
	  if (confd > maxfd)
	    maxfd = confd;
	  break;
	}
      
      if (select(maxfd+1, &rset, &wset, NULL, NULL) == -1)
	continue;

      if (FD_ISSET(udpfd, &rset))
	{
	  int n = recvfrom(udpfd, packet, PACKETSZ, 0, &udpaddr, &udplen); 
	  if (n > sizeof(HEADER))
	    {
	      n = process_request((HEADER *)packet, packet + PACKETSZ);
	      sendto(udpfd, packet, n, 0, &udpaddr, udplen);  
	    }
	}
      
      switch (state)
	{
	case ACCEPT:
	  if (FD_ISSET(listenfd, &rset))
	    {
	      confd = accept(listenfd, &tcpaddr, &tcplen);
	      if (confd != -1)
		state = READL0;
	    }
	  break;

	case READL0:
	  if (FD_ISSET(confd, &rset))
	    {
	      unsigned char c;
	      if (read(confd, &c, 1) == 1)
		{
		  reqsize = c<<8;
		  state = READL1;
		}
	    }
	  break;

	case READL1:
	  if (FD_ISSET(confd, &rset))
	    {
	      int val;
	      unsigned char c;
	      if (read(confd, &c, 1) == 1)
		{
		  reqsize |= c;
		  /* Size: we check after adding each record, so there must
		     be memory for the largest record in excess of the
		     limit. We arbritrarily limit the reply size to
		     four times the query size. */
		  repmax = reqsize*4;
		  tcppacket = readp = malloc(repmax+MAXDNAME+RRFIXEDSZ);
		  if (!tcppacket)
		    {
		      close(confd);
		      state = ACCEPT;
		    }
		  else
		    {
		      val = fcntl(confd, F_GETFL, 0); /* set non-blocking */
		      fcntl(confd, F_SETFL, val | O_NONBLOCK);
		      state = READ;
		    }
		}
	    }
	  break;

	case READ:
	  if (FD_ISSET(confd, &rset))
	    {
	      int n = read(confd, readp, reqsize);
	      if (n > 0)
		{ 
		  readp += n;
		  reqsize -= n;
		  if (reqsize == 0)
		    {
		      repsize = process_request((HEADER *)tcppacket,
						tcppacket + repmax);
		      writep = tcppacket;
		      state = WRITEL0;
		    }
		}
	    }
	  break;
	
	case WRITEL0:
	  if (FD_ISSET(confd, &wset))
	    {
	      unsigned char c = repsize >> 8;
	      if (write(confd, &c, 1) == 1)
		state = WRITEL1;
	    }
	  break;
	
	case WRITEL1:
	  if (FD_ISSET(confd, &wset))
	    {
	      unsigned char c = repsize & 255;
	      if (write(confd, &c, 1) == 1)
		state = WRITE;
	    }
	  break;
	
	case WRITE:
	  if (FD_ISSET(confd, &wset))
	    {
	      int n = write(confd, writep, repsize);
	      if (n > 0)
		{
		  writep += n;
		  repsize -= n;
		  if (repsize == 0)
		    {
		      free(tcppacket);
		      close(confd);
		      state = ACCEPT;
		    }
		}
	    }
	  break;
      	}
    }
}

static int process_request(HEADER *header, unsigned char *limit)
{
  unsigned char *ansp, *namep, *p, *p1 ;
  int qtype, qclass;
  char name[MAXDNAME];
  char *cp;
  unsigned int j,l,q;
  int qdcount = ntohs(header->qdcount);
  int opcode = header->opcode;

  header->ancount = htons(0);
  header->nscount = htons(0);
  header->arcount = htons(0);

  header->tc = 0;

  if (!qdcount)
    {
      header->rcode = htons(FORMERR);
      header->qr = 1;
      header->ra = 1;
      return sizeof(HEADER);
    }
  
  /* determine end of question section (we put answers there) */
  p = ansp = (char *)(header+1);
  for (q=0; q<qdcount; q++)
    {
      while (1)
	{
	  if (((*ansp) & 0xc0) == 0xc0) /* pointer for name compression */
	    {
	      ansp += 2;
	      break;
	    }
	  else if (*ansp) /* another segment */
	    ansp += (*ansp) + 1;
	  else            /* end */
	    {
	      ansp++;
	      break;
	    }
	}
      ansp += 4; /* class and type */
    }

  /* now process each question, answers go in RRs after the question */
  for (q=0; q<qdcount; q++)
    {
      /* save pointer to name for copying into answers */
      namep = p;

      /* now extract name as .-concatenated string into name */
      cp = name;
      p1 = NULL;
      while ((l = *p++))
	{
	  if ((l & 0xc0) == 0xc0) /* pointer */
	    { 
	      /* get offset */
	      l = (l&0x3f) << 8;
	      l |= *p++;
	      if (!p1) /* first jump, save location to go back to */
		p1 = p;
	      p = l + (unsigned char *)header;
	    }
	  else
	    {
	      for(j=0; j<l; j++)
		*cp++ = tolower(*p++);
	      *cp++ = '.';
	    }
	}
      *--cp = 0; /* overwrite last period */
	  
      if (p1) /* we jumped via compression */
	p = p1;

      GETSHORT(qtype, p); 
      GETSHORT(qclass, p);
  
      if ((opcode == QUERY) && (qclass == C_IN) && (qtype == T_PTR))
	do_reverse_lookup(header, name, namep, limit, &ansp);
      else if ((opcode == QUERY) && (qclass == C_IN) && (qtype == T_A))
	do_forward_lookup(header, name, namep, limit, &ansp);
      else if ((opcode == QUERY) && (qclass == C_IN) && (qtype == T_MX))
	do_mx_lookup(header, name, namep, limit, &ansp);
      
    }
  /* done all questions, set up header and return result */
  
  header->qr = 1; /* response */
  header->aa = 0; /* authoritive - never */
  header->ra = 1; /* recursion if available */
  header->rcode = htons(NOERROR); /* no error */
  return ansp - (unsigned char *)header;
}

static void do_forward_lookup(HEADER *header, char *name, unsigned char *namep,
			      unsigned char *limit, unsigned char **anspp)
{
  struct hostent *ent = gethostbyname(name);
  unsigned char *p = *anspp;
  int i;

  if (!ent) /* failed lookup */
    return;
  
  for(i=0; ent->h_addr_list[i]; i++)
    {
      /* copy question as first part of answer (use compression)*/
  
      PUTSHORT((namep - (unsigned char *)header) | 0xc000, p); 
      PUTSHORT(T_A, p);
      PUTSHORT(C_IN, p);
      PUTLONG(0, p); /* TTL -- zero means this transaction only */
      
      PUTSHORT(INADDRSZ, p);
      memcpy(p, ent->h_addr_list[i], ent->h_length);
      p += ent->h_length;
     
      if (limit && ((limit - p) < 0))
	{
	  /* last answer exceeded packet size, set truncated bit */
	  header->tc = 1;
	  break;
	}
      else
	{
	  header->ancount = htons(ntohs(header->ancount)+1);
	  *anspp = p;
	}
    }
}


static void do_reverse_lookup(HEADER *header, char *name, unsigned char *namep,
			      unsigned char *limit, unsigned char **anspp)
{
  struct hostent *ent;
  unsigned char *p = *anspp;
  unsigned char *sav;
  char *cp1, *cp2;
  int i,j;
  unsigned char addr[4];
  
  /* turn name into a series of asciiz strings */
  /* j counts no of labels */
  for(j = 1,cp1 = name; *cp1; cp1++)
    if (*cp1 == '.')
      {
	*cp1 = 0;
	j++;
      }
    
  addr[0] = addr[1] = addr[2] = addr[3] = 0;

  /* address arives as a name of the form
     www.xxx.yyy.zzz.in-addr.arpa
     some of the low order address octets might be missing
     and should be set to zero. */
  for (cp1 = name,i=0; i<j; i++)
    {
      if (strcmp(cp1, "in-addr") == 0)
	break;
      addr[3] = addr[2];
      addr[2] = addr[1];
      addr[1] = addr[0];
      addr[0] = atoi(cp1);
      cp1 += strlen(cp1)+1;
    }
  
  ent = gethostbyaddr(addr, 4, AF_INET);
  
  if (!ent) /* failed lookup */
    return;
  
  /* copy question as first part of answer (use compression) */
  
  PUTSHORT((namep - (unsigned char *)header) | 0xc000, p); 
  PUTSHORT(T_PTR, p);
  PUTSHORT(C_IN, p);
  PUTLONG(0, p); /* TTL -- zero means this transaction only */
  
  sav = p;
  PUTSHORT(0, p); /* dummy RDLENGTH */
  cp1 = ent->h_name;
  while (*cp1) 
    {
      cp2 = p++;
      for (j=0; *cp1 && (*cp1 != '.'); cp1++, j++)
	*p++ = *cp1;
      *cp2 = j;
      if (*cp1)
	cp1++;
    }
  *p++ = 0;
  j = p - sav - 2;
  PUTSHORT(j, sav); /* Real RDLENGTH */
   
  if (limit &&( (limit - p) < 0))
    /* last answer exceeded packet size, set truncated bit */
    header->tc = 1;
  else
    {
      header->ancount = htons(ntohs(header->ancount)+1);
      *anspp = p;
    }
}

static void do_mx_lookup(HEADER *header, char *name, unsigned char *namep,
			 unsigned char *limit, unsigned char **anspp)
{
  unsigned char *p = *anspp;
  unsigned char *sav, *hostnamep;
  char hostname[MAXDNAME];
  char *cp1, *cp2;
  int j;
  
  if (!mxname)
    return;

  if (gethostname(hostname, MAXDNAME) != 0)
    return;

  /* we return an mx record for a name given on the command line */
  if (strcmp(name, mxname) != 0)
    return;
  
  PUTSHORT((namep - (unsigned char *)header) | 0xc000, p);       
  PUTSHORT(T_MX, p);
  PUTSHORT(C_IN, p);
  PUTLONG(0, p); /* TTL -- zero means this transaction only */
      
  sav = p;
  PUTSHORT(0, p); /* dummy RDLENGTH */
  
  PUTSHORT (1, p); /* preference */

  cp1 = hostname;
  hostnamep = p;
  while (*cp1) 
    {
      cp2 = p++;
      for (j=0; *cp1 && (*cp1 != '.'); cp1++, j++)
	*p++ = *cp1;
      *cp2 = j;
      if(*cp1)
	cp1++;
    }
  *p++ = 0;
  j = p - sav - 2;
  PUTSHORT(j, sav); /* Real RDLENGTH */

  if (limit && ((limit - p) < 0))
    /* last answer exceeded packet size, set truncated bit */
    header->tc = 1;
  else
    {
      header->ancount = htons(ntohs(header->ancount)+1);
      *anspp = p;
  
      /* add an A answer for the host we just returned as answer to MX query */
      do_forward_lookup(header, hostname, hostnamep, limit, anspp);
    } 
}
