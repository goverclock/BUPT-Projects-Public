/* dnsmasq is Copyright (c) 2000 Simon Kelley

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 dated June, 1991.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
*/

#include "dnsmasq.h"

static struct crec *cache_head, *cache_tail;
static int cache_inserted, cache_live_freed;

static struct crec *cache_get_free(time_t now);
static void cache_free(struct crec *crecp);
static void cache_unlink (struct crec *crecp);

void cache_init(int cachesize)
{
  struct crec *crecp;
  int i;

  if (!(crecp = (struct crec *)malloc(cachesize*sizeof(struct crec))))
    {
      fprintf(stderr, "dnsmasq: could not get memory");
      exit(1);
    }

  cache_head = NULL;
  cache_tail = crecp;
  for (i=0; i<cachesize; i++, crecp++)
    cache_insert(crecp);

  cache_inserted = cache_live_freed = 0;
}


/* get a cache entry to re-cycle from the tail of the list (oldest entry) */
static struct crec *cache_get_free(time_t now)
{
  struct crec *ret = cache_tail;

  cache_tail = cache_tail->prev;
  cache_tail->next = NULL;

  /* just push immortal entries back to the top and try again. */
  if (ret->flags & (F_HOSTS | F_DHCP))
    {
      cache_insert(ret);
      return cache_get_free(now);
    }

  /* record still-live cache entries we have to blow away */
  if ((ret->flags & (F_FORWARD | F_REVERSE)) &&
      ret->ttd >= now)
    cache_live_freed++;

  cache_inserted++;
	
  /* The next bit ensures that if there is more than one entry
     for a name or address, they all get removed at once */
  if (ret->flags & F_FORWARD)
    cache_remove_old_name(ret->name, now);
  else if (ret->flags & F_REVERSE)
    cache_remove_old_addr(ret->addr, now);
  
  return ret;
}

/* Note that it's OK to free slots with F_DHCP set */
/* They justfloat around unused until the new dhcp.leases load */
static void cache_free(struct crec *crecp)
{
  cache_unlink(crecp);
  crecp->flags &= ~F_FORWARD;
  crecp->flags &= ~F_REVERSE;
  cache_tail->next = crecp;
  crecp->prev = cache_tail;
  crecp->next = NULL;
  cache_tail = crecp;
}

/* insert a new cache entry at the head of the list (youngest entry) */
void cache_insert(struct crec *crecp)
{
  if (cache_head) /* check needed for init code */
    cache_head->prev = crecp;
  crecp->next = cache_head;
  crecp->prev = NULL;
  cache_head = crecp;
}

/* remove an arbitrary cache entry for promotion */ 
static void cache_unlink (struct crec *crecp)
{
  if (crecp->prev)
    crecp->prev->next = crecp->next;
  else
    cache_head = crecp->next;

  if (crecp->next)
    crecp->next->prev = crecp->prev;
  else
    cache_tail = crecp->prev;
}

void cache_mark_all_old(void)
{
  struct crec *crecp;
  
  for (crecp = cache_head; crecp; crecp = crecp->next)
    crecp->flags &= ~F_NEW;
}

void cache_remove_old_name(char *name, time_t now)
{
  struct crec *crecp = cache_head;
  while (crecp)
    {
      struct crec *tmp = crecp->next;
      if (crecp->flags & F_FORWARD) 
	{
	  if (strcmp(crecp->name, name) == 0 && 
	      !(crecp->flags & (F_HOSTS | F_NEW | F_DHCP)))
	    cache_free(crecp);
	  
	  if ((crecp->ttd < now) && !(crecp->flags & F_IMMORTAL))
	    cache_free(crecp);
	}
      crecp = tmp;
    }
  
}

void cache_remove_old_addr(struct in_addr addr, time_t now)
{
  struct crec *crecp = cache_head;
  while (crecp)
    {
      struct crec *tmp = crecp->next;
      if (crecp->flags & F_REVERSE)
	{
	  
	  if (crecp->addr.s_addr == addr.s_addr && 
	      !(crecp->flags & (F_HOSTS | F_NEW | F_DHCP)))
	    cache_free(crecp);
	  
	  /* remove expired entries too. */
	  if ((crecp->ttd < now) && !(crecp->flags & F_IMMORTAL))
	    cache_free(crecp);
	}
      crecp = tmp;
    }
  
}

void cache_name_insert(char *name, struct in_addr *addr, 
		       time_t now, unsigned long ttl)
{
  struct crec *crecp = cache_get_free(now);
  crecp->flags = F_NEW | F_FORWARD;
  strcpy(crecp->name, name);
  if (addr)
    crecp->addr = *addr;
  else
    crecp->flags |= F_NEG;
  crecp->ttd = ttl + now;
  cache_insert(crecp);
}

void cache_addr_insert(char *name, struct in_addr *addr, 
		       time_t now, unsigned long ttl)
{
  struct crec *crecp = cache_get_free(now);
  crecp->flags = F_NEW | F_REVERSE;
  strcpy(crecp->name, name);
  crecp->addr = *addr;
  crecp->ttd = ttl + now;
  cache_insert(crecp);
}

struct crec *cache_find_by_name(struct crec *crecp, char *name, time_t now)
{
  if (crecp) /* iterating */
    {
      if (crecp->next && 
	  (crecp->next->flags & F_FORWARD) && 
	  strcmp(crecp->next->name, name) == 0)
	return crecp->next;
      else
	return NULL;
    }
  
  /* first search, look for relevant entries and push to top of list
     also free anything which has expired */
  
  crecp = cache_head;
  while (crecp)
    {
      struct crec *tmp = crecp->next;
      if ((crecp->flags & F_FORWARD) && 
	  (strcmp(crecp->name, name) == 0))
	{
	  if ((crecp->flags & F_IMMORTAL) || crecp->ttd > now)
	    {
	      cache_unlink(crecp);
	      cache_insert(crecp);
	    }
	  else
	    cache_free(crecp);
	}
      crecp = tmp;
    }

  /* if there's anything relevant, it will be at the head of the cache now. */

  if (cache_head && (cache_head->flags & F_FORWARD) &&
      (strcmp(cache_head->name, name) == 0))
    return cache_head;

  return NULL;
}

struct crec *cache_find_by_addr(struct crec *crecp, struct in_addr addr, time_t now)
{
  if (crecp) /* iterating */
    {
      if (crecp->next && (crecp->next->flags & F_REVERSE) && crecp->next->addr.s_addr == addr.s_addr)
	return crecp->next;
      else
	return NULL;
    }
  
  /* first search, look for relevant entries and push to top of list
     also free anything which has expired */
  
  crecp = cache_head;
  while (crecp)
    {
      struct crec *tmp = crecp->next;
      if ((crecp->flags & F_REVERSE) && 
	  crecp->addr.s_addr == addr.s_addr)
	{	    
	  if ((crecp->flags & F_IMMORTAL) || crecp->ttd > now)
	    {
	      cache_unlink(crecp);
	      cache_insert(crecp);
	    }
	  else
	      cache_free(crecp);
	}
      crecp = tmp;
    }

  /* if there's anything relevant, it will be at the head of the cache now. */

  if (cache_head && (cache_head->flags & F_REVERSE) &&
      cache_head->addr.s_addr == addr.s_addr)
    return cache_head;
  
  return NULL;
}

void cache_reload(int use_hosts, int cachesize)
{
  struct crec *cache;
  FILE *f;
  char *line, buff[MAXLIN];

  for (cache=cache_head; cache; cache = cache->next)
    if (cache->flags & F_HOSTS)
      {
	cache_unlink(cache);
	free(cache);
      }
    else if (!cache->flags & F_DHCP)
      cache->flags = 0;
  
  if (!use_hosts && (cachesize > 0))
    {
      syslog(LOG_INFO, "cleared cache");
      return;
    }
  
  f = fopen(HOSTSFILE, "r");
  
  if (!f)
    {
      syslog(LOG_ERR, "failed to load names from %s: %m", HOSTSFILE);
      return;
    }
  
  syslog(LOG_INFO, "reading %s", HOSTSFILE);
  
  while ((line = fgets(buff, MAXLIN, f)))
    {
      struct in_addr addr;
      char *token = strtok(line, " \t\n");
      int flags = F_HOSTS | F_IMMORTAL | F_FORWARD | F_REVERSE;
          
      if (!token || (*token == '#') || !inet_aton(token, &addr))
	continue;
      
      while ((token = strtok(NULL, " \t\n")) && (*token != '#'))
	if ((cache = (struct crec *) malloc(sizeof(struct crec))))
	  {
	    char *cp;
	    for (cp = cache->name; *token; token++, cp++)
	      *cp = tolower(*token);
	    *cp = 0;
	    cache->flags = flags;
	    cache->addr = addr;
	    cache_insert(cache);
	    /* Only the first name is canonical, and should be returned to reverse queries */
	    flags =  F_HOSTS | F_IMMORTAL | F_FORWARD;
	  }
    }

  fclose(f);
}
	    

struct crec *cache_clear_dhcp(void)
{
  struct crec *cache = cache_head, *ret = NULL;
  
  while (cache)
    {
      struct crec *tmp = cache->next;
      if (cache->flags & F_DHCP)
	{
	  cache_unlink(cache);
	  cache->next = ret;
	  ret = cache;
	}
      cache = tmp;
    }
  return ret;
}

void dump_cache(int daemon, int cache_size)
{
  if (daemon)
    syslog(LOG_INFO, "Cache size %d, %d/%d cache insertions re-used unexpired cache entries.", 
	   cache_size, cache_live_freed, cache_inserted); 
  else
    {
      struct crec *cache ;
      printf("Dnsmasq: Cache size %d, %d/%d cache insertions re-used unexpired cache entries.\n",
	     cache_size, cache_live_freed, cache_inserted); 
      printf("Host                                     Address         Flags   Expires\n");
      
      for(cache = cache_head ; cache ; cache = cache->next)
	if (cache->flags & (F_FORWARD | F_REVERSE))
	  printf("%-40.40s %-15.15s %s%s%s%s%s%s  %s",
		 cache->name, 
		 cache->flags & F_NEG ? "" : inet_ntoa(cache->addr), 
		 cache->flags & F_FORWARD ? "F" : " ",
		 cache->flags & F_REVERSE ? "R" : " ",
		 cache->flags & F_IMMORTAL ? "I" : " ",
		 cache->flags & F_DHCP ? "D" : " ",
		 cache->flags & F_NEG ? "N" : " ",
                 cache->flags & F_HOSTS ? "H" : " ",
		 cache->flags & F_IMMORTAL ? "\n" : ctime(&(cache->ttd))) ;
    }
}

