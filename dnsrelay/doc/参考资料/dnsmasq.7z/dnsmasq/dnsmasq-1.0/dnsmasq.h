/* dnsmasq is Copyright (c) 2000 Simon Kelley

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 dated June, 1991.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
*/

/* See RFC1035 for details of the protocol this code talks. */

/* Author's email: simon@thekelleys.org.uk */

#define VERSION "1.0"

#define FTABSIZ 20 /* max number of outstanding requests */
#define CACHESIZ 300 /* default cache size */
#define MAXLIN 1024 /* line length in config files */
#define HOSTSFILE "/etc/hosts"
#define RESOLVFILE "/etc/resolv.conf"
#define RUNFILE "/var/run/dnsmasq.pid"
#define CHUSER "nobody"

#include <arpa/nameser.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <net/if.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ctype.h>
#include <signal.h>
#include <syslog.h>
#include <getopt.h>
#include <time.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>

struct crec { 
  char name[MAXDNAME];
  struct in_addr addr;
  struct crec *next, *prev;
  time_t ttd; /* time to die */
  int flags;
};

#define F_IMMORTAL  1
#define F_NEW       2
#define F_REVERSE   4
#define F_FORWARD   8
#define F_DHCP      16 
#define F_NEG       32       
#define F_HOSTS     64

struct server {
  struct sockaddr_in addr;
  struct server *next; /* circle */
};

/* linked list of all the interfaces in the system and 
   the sockets we have bound to each one. */
struct irec {
  struct sockaddr_in addr;
  int fd;
  struct irec *next;
};

struct iname {
  char *name;
  struct iname *next;
  int found;
};

struct frec {
  struct sockaddr source;
  struct server *sentto;
  unsigned short orig_id, new_id;
  int fd;
  time_t time;
};

/* cache.c */
void cache_init(int cachesize);
void cache_mark_all_old(void);
struct crec *cache_find_by_addr(struct crec *crecp,
				struct in_addr addr, time_t now);
struct crec *cache_find_by_name(struct crec *crecp, char *name, time_t now);
void cache_mark_all_old(void);
void cache_remove_old_name(char *name, time_t now);
void cache_remove_old_addr(struct in_addr addr, time_t now);
void cache_insert(struct crec *crecp);
void cache_name_insert(char *name, struct in_addr *addr, 
		       time_t now, unsigned long ttl);
void cache_addr_insert(char *name, struct in_addr *addr,
		       time_t now, unsigned long ttl);
void cache_reload(int use_hosts, int cachesize);
struct crec *cache_clear_dhcp(void);
void dump_cache(int daemon, int size);

/* rfc1035.c */
void extract_addresses(HEADER *header, int qlen);
void extract_neg_addrs(HEADER *header, int qlen);
int answer_request(HEADER *header, char *limit, int qlen,
		   char *mxname, int boguspriv);

/* dhcp.c */
void load_dhcp(char *file, char *suffix);
