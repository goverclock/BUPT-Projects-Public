/* dnsmasq is Copyright (c) 2000 Simon Kelley

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 dated June, 1991.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
*/

/* See RFC1035 for details of the protocol this code talks. */

/* Author's email: simon@thekelleys.org.uk */

#include "dnsmasq.h"

static struct server *last_server;  
static struct frec *ftab;
static int sighup, sigusr1;

static struct option opts[] = { 
  {"version", no_argument, 0, 'v'},
  {"no-hosts", no_argument, 0, 'h'},
  {"help", no_argument, 0, '?'},
  {"no-daemon", no_argument, 0, 'd'},
  {"resolv-file", required_argument, 0, 'r'},
  {"mx-host", required_argument, 0, 'm'},
  {"cache-size", required_argument, 0, 'c'},
  {"port", required_argument, 0, 'p'},
  {"dhcp-lease", required_argument, 0, 'l'},
  {"domain-suffix", required_argument, 0, 's'},
  {"interface", required_argument, 0, 'i'},
  {"bogus-priv", no_argument, 0, 'b'}
};

static void forward_query(int udpfd, 
			  int peerfd,
			  struct sockaddr *udpaddr, 
			  HEADER *header,
			  int plen);
static void reload_servers(char *fname, struct irec *interfaces, int port);
static void *safe_malloc(int size);
static struct irec *find_all_interfaces(struct iname *names, int fd);
static void sig_handler(int sig);
static struct frec *get_new_frec(time_t now);
static struct frec *lookup_frec(unsigned short id);
static struct frec *lookup_frec_by_sender(unsigned short id,
					  struct sockaddr *addr);
static unsigned short get_id(void);


int main (int argc, char **argv)
{
  int i, cachesize = CACHESIZ;
  int port = NAMESERVER_PORT;
  int peerfd, option; 
  int use_hosts = 1, daemon = 1;
  char *resolv = RESOLVFILE;
  time_t resolv_changed = 0;
  off_t lease_file_size = (off_t)0;
  ino_t lease_file_inode;
  struct irec *iface, *interfaces = NULL;
  char *mxname = NULL;
  char *lease_file = NULL;
  char *domain_suffix = NULL;
  int boguspriv = 0;
  struct iname *if_names = NULL;

  sighup = 1; /* init cache the first time through */
  sigusr1 = 0; /* but don't dump */
  signal(SIGUSR1, sig_handler);
  signal(SIGHUP, sig_handler);

  last_server = NULL;
  
  opterr = 0;

  while (1)
    {
      option = getopt_long(argc, argv, "bvhdr:m:p:c:l:s:i:", opts, NULL);
      
      if (option == 'b')
	  boguspriv = 1;
	
      if (option == 'v')
	{
	  fprintf(stderr, "dnsmasq version %s\n", VERSION);
	  exit(0);
	}

      if (option == 'h')
	use_hosts = 0;

      if (option == 'd')
	daemon = 0;
      
      if (option == 'r')
	{
	  resolv = safe_malloc(strlen(optarg)+1);
	  strcpy(resolv, optarg);
	}

      if (option == 'm')
	{
	  mxname = safe_malloc(strlen(optarg)+1);
	  strcpy(mxname, optarg);
	}

      if (option == 'l')
        {
          lease_file = safe_malloc(strlen(optarg)+1);
          strcpy(lease_file, optarg);
        }
      
      if (option == 's')
	{
          domain_suffix = safe_malloc(strlen(optarg)+1);
          strcpy(domain_suffix, optarg);
        }
      
      if (option == 'i')
	{
	  struct iname *new = (struct iname *)safe_malloc(sizeof(struct iname));
	  new->next = if_names;
	  if_names = new;
	  new->name = safe_malloc(strlen(optarg)+1);
	  strcpy(new->name, optarg);
	  new->found = 0;
	}

      if (option == 'c')
	{
	  cachesize = atoi(optarg);
	  /* zero is OK, and means no caching.
	     Very low values cause prolems with  hosts
	     with many A records. */
	  
	  if (cachesize < 0)
	    option = '?'; /* error */
	  else if ((cachesize > 0) && (cachesize < 20))
	    cachesize = 20;
	  else if (cachesize > 1000)
	    cachesize = 1000;
	}

      if (option == 'p')
	port = atoi(optarg);
      
      if (option == '?')
	{ 
	  fprintf (stderr,
                   "Usage: dnsmasq [options]\n"
                   "\nValid options are :\n"
                   "-v, --version               Display dnsmasq version.\n"
                   "-d, --no-daemon             Do NOT fork into the background.\n"
                   "-h, --no-hosts              Do NOT load " HOSTSFILE " file.\n"
		   "-b, --bogus-priv            Fake reverse lookups for RFC1918 private address ranges.\n"
                   "-r, --resolv-file=path      Specify path to resolv.conf (defaults to " RESOLVFILE ").\n"
                   "-p, --port=number           Specify port to listen for DNS requests on (defaults to 53).\n"
                   "-m, --mx-host=host_name     Specify the MX name to reply to.\n"
                   "-c, --cache-size=cachesize  Specify the size of the cache in entries (defaults to %d).\n"
                   "-l, --dhcp-lease=path       Specify the path to the DHCP lease file.\n"
                   "-s, --domain-suffix=domain  Specify the domain suffix which DHCP entries will use.\n"
		   "-i, --interface=interface   Specify interface(s) to listen on.\n"
                   "-?, --help                  Display this message.\n"
                   "\n", CACHESIZ);
          exit (0);
	}
      
      if (option == -1)
	break;
    }

  /* peerfd is not bound to a low port
     so that we can send queries out on it without them getting
     blocked at firewalls */
  
  if ((peerfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    {
      perror("dnsmasq: cannot create socket");
      exit(1);
    }
  
  interfaces = find_all_interfaces(if_names, peerfd);

  /* open a socket bound to NS port on each local interface.
     this is necessary to ensure that our replies originate from
     the address they were sent to. See Stevens page 531 */
  for (iface = interfaces; iface; iface = iface->next)
    {
      iface->addr.sin_port = htons(port);
      if ((iface->fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
	  perror("dnsmasq: cannot create socket");
	  exit(1);
	}
      
      if (bind(iface->fd, 
	       (struct sockaddr *)&iface->addr, sizeof(iface->addr)))
	{
	  perror("dnsmasq: bind failed");
	  exit(1);
	}
    }

  ftab = (struct frec *)safe_malloc(FTABSIZ*sizeof(struct frec));
  for (i=0; i<FTABSIZ; i++)
    ftab[i].new_id = 0;
  
  cache_init(cachesize);

  if (daemon)
    {
      FILE *pidfile;
      struct passwd *ent_pw;
        
      /* The following code "daemonizes" the process. 
	 See Stevens section 12.4 */

      if (fork() != 0 )
	exit(0);
      
      setsid();
      
      if (fork() != 0)
	exit(0);
      
      chdir("/");
      umask(022); /* make pidfile 0644 */
      
      /* write pidfile _after_ forking ! */
      if ((pidfile = fopen(RUNFILE, "w")))
      	{
	  fprintf(pidfile, "%d\n", getpid());
	  fclose(pidfile);
	}
      
      umask(0);

      for (i=0; i<64; i++)
	{
	  if (i == peerfd)
	    continue;
	  for (iface = interfaces; iface; iface = iface->next)
	    if (iface->fd == i)
	      break;
	  if (!iface)
	    close(i);
	}

      /* Change uid and gid to "nobody" for security */
      if ((ent_pw = getpwnam(CHUSER)))
	{
	  setreuid(ent_pw->pw_uid, ent_pw->pw_uid);
	  if (getgrgid(ent_pw->pw_gid))
	    setregid(ent_pw->pw_gid, ent_pw->pw_gid);
	}
    }
  
  openlog("dnsmasq", LOG_PID, LOG_DAEMON);
  
  if (cachesize)
    syslog(LOG_INFO, "started, version %s cachesize %d", VERSION, cachesize);
  else
    syslog(LOG_INFO, "started, version %s cache disabled", VERSION);
  
  if (mxname)
    syslog(LOG_INFO, "serving MX record for mailhost %s", mxname);
  
  if (getuid() == 0 || geteuid() == 0)
    syslog(LOG_WARNING, "failed to drop root privs");
  
  while (1)
    {
      /* Size: we check after adding each record, so there must be 
	 memory for the largest packet, and the largest record */
      char packet[PACKETSZ+MAXDNAME+RRFIXEDSZ];
      int ready, maxfd = peerfd;
      fd_set rset;
      HEADER *header;
      struct stat statbuf;
      
      FD_ZERO(&rset);
      FD_SET(peerfd, &rset);
      for (iface = interfaces; iface; iface = iface->next)
	{
	  FD_SET(iface->fd, &rset);
	  if (iface->fd > maxfd)
	    maxfd = iface->fd;
	}
      
      ready = select(maxfd+1, &rset, NULL, NULL, NULL);

      if (ready == -1)
	{
	  if (errno == EINTR)
	    ready = 0; /* do signal handlers */
	  else
	    continue;
	}

      if (sigusr1)
	{
	  signal(SIGUSR1, SIG_IGN);
	  dump_cache(daemon, cachesize);
	  sigusr1 = 0;
	  signal(SIGUSR1, sig_handler);
	}

      if (sighup)
	{
	  signal(SIGHUP, SIG_IGN);
	  cache_reload(use_hosts, cachesize);
	  sighup = 0;
	  signal(SIGHUP, sig_handler);
	}
      
      if ((stat(resolv, &statbuf) == 0) && 
	  (statbuf.st_mtime > resolv_changed) &&
	  (statbuf.st_mtime < time(NULL) || resolv_changed == 0))
	{
	  resolv_changed = statbuf.st_mtime;
	  reload_servers(resolv, interfaces, port);
	}

      if (lease_file && (stat(lease_file, &statbuf) == 0) &&
	  ((lease_file_size == (off_t)0) ||
	   (statbuf.st_size > lease_file_size) ||
	   (statbuf.st_ino != lease_file_inode)))
	{
	  lease_file_size = statbuf.st_size;
	  lease_file_inode = statbuf.st_ino;
	  load_dhcp(lease_file, domain_suffix);
	}
		
      if (ready == 0)
	continue; /* no sockets ready */

      if (FD_ISSET(peerfd, &rset))
	{
	  /* packet from peer server, extract data for cache, and send to
	     original requester */
	  struct frec *forward;
	  int n = recvfrom(peerfd, packet, PACKETSZ, 0, NULL, NULL);
 
	  header = (HEADER *)packet;
	  if (n >= sizeof(HEADER) && header->qr)
	    {
	      if ((forward = lookup_frec(ntohs(header->id))))
		{
		  if (header->rcode == NOERROR)
		    {
		      last_server = forward->sentto; /* known good */
		      if (cachesize != 0 && header->opcode == QUERY)
			extract_addresses(header, n);
		    }
		  else if (header->rcode == NXDOMAIN)
		    {
		      last_server = forward->sentto; /* known good */
		      if (cachesize != 0 && header->opcode == QUERY)
			extract_neg_addrs(header, n);
		    }
		  header->id = htons(forward->orig_id);
		  sendto(forward->fd, packet, n, 0, 
			 &forward->source, sizeof(forward->source));
		  forward->new_id = 0; /* cancel */
		}
	    }
	}
      
      for (iface = interfaces; iface; iface = iface->next)
	{
	  if (FD_ISSET(iface->fd, &rset))
	    {
	      /* request packet, deal with query */
	      struct sockaddr udpaddr;
	      socklen_t udplen = sizeof(udpaddr);
	      int m, n = recvfrom(iface->fd, packet, PACKETSZ, 0, &udpaddr, &udplen); 
	      /* DS: Kernel 2.2.x complains if AF_INET isn't set */
	      ((struct sockaddr_in *)&udpaddr)->sin_family = AF_INET;
	      
	      header = (HEADER *)packet;
	      if (n >= sizeof(HEADER) && !header->qr)
		{
		  if ((m = answer_request(header, ((char *)header) + PACKETSZ, n, 
					  mxname, boguspriv)))
		    {
		      /* answered from cache, send reply */
		      sendto(iface->fd, (char *)header, m, 0, 
			     &udpaddr, sizeof(struct sockaddr));
		    }
		  else
		    {
		      /* cannot answer from cache, send on to real nameserver */
		      forward_query(iface->fd, peerfd, &udpaddr, header, n);
		    }

		}
	      
	    }
	}
    }

  return 0;
}

/* for use during startup */
static void *safe_malloc(int size)
{
  void *ret = malloc(size);
  
  if (!ret)
    {
      fprintf(stderr, "dnsmasq: could not get memory\n");
      exit(1);
    }
 
  return ret;
}
    
static struct irec *find_all_interfaces(struct iname *names, int fd)
{
  /* this code is adapted from Stevens, page 434. It finally
     destroyed my faith in the C/unix API */
  int len = 100 * sizeof(struct ifreq);
  int lastlen = 0;
  char *buf, *ptr;
  struct ifconf ifc;
  struct irec *ret = NULL;

  while (1)
    {
      buf = safe_malloc(len);
      ifc.ifc_len = len;
      ifc.ifc_buf = buf;
      if (ioctl(fd, SIOCGIFCONF, &ifc) < 0)
	{
	  if (errno != EINVAL || lastlen != 0)
	    {
	      perror("dnsmasq: ioctl error while enumerating interfaces");
	      exit(1);
	    }
	}
      else
	{
	  if (ifc.ifc_len == lastlen)
	    break; /* got a big enough buffer now */
	  lastlen = ifc.ifc_len;
	}
      len += 10* sizeof(struct ifreq);
      free(buf);
    }

  for (ptr = buf; ptr < buf + ifc.ifc_len; ptr += sizeof(struct ifreq))
    {
      struct ifreq *ifr = (struct ifreq *) ptr;
      
      if (ifr->ifr_addr.sa_family == AF_INET)
	{
	  struct irec *iface;
	  /* copy since getting flags overwrites */
	  struct sockaddr_in iface_addr = *((struct sockaddr_in *)&ifr->ifr_addr);  
	  
	  /* get iface flags, since we need to distinguish loopback interfaces */
	  if (ioctl(fd, SIOCGIFFLAGS, ifr) < 0)
	    {
	      perror("dnsmasq: ioctl error getting interface flags");
	      exit(1);
	    }

	  /* we may need to check the whitelist */
	  if (names)
	    { 
	      struct iname *tmp;
	      for(tmp = names; tmp; tmp = tmp->next)
		if (strcmp(tmp->name, ifr->ifr_name) == 0)
		  {
		    tmp->found = 1;
		    break;
		  }
	      if (!(ifr->ifr_flags & IFF_LOOPBACK) && !tmp) /* not on whitelist and not loopback */
		continue;
	    }

	  /* check whether the interface IP has been added already 
	     it is possible to have multiple interfaces with the same address. */
	  for (iface = ret; iface; iface = iface->next) 
	    if (memcmp(&iface->addr, &iface_addr, sizeof(struct sockaddr)) == 0)
	      break;
	  if (iface) 
	    continue;
	  	  
	  /* If OK, add it to the head of the list */
	  iface = safe_malloc(sizeof(struct irec));
	  iface->addr = iface_addr;
	  iface->next = ret;
	  ret = iface;
	}
    }

  /* if a whitelist provided, make sure the if names on it were OK */
  while(names)
    {
      if (!names->found)
	{
	  fprintf(stderr, "dnsmasq: unknown interface %s\n", names->name);
	  exit(1);
	}
      names = names->next;
    }
    
  free(buf);
  return ret;
}

static void sig_handler(int sig)
{
  if (sig == SIGHUP)
    sighup = 1;
  else if (sig == SIGUSR1)
    sigusr1 = 1;
}

static void reload_servers(char *fname, struct irec *interfaces, int port)
{
  FILE *f;
  char *line, buff[MAXLIN];
  int i;

  f = fopen(fname, "r");
  if (!f)
    {
      syslog(LOG_ERR, "failed to read %s: %m", fname);
      return;
    }
  
  syslog(LOG_INFO, "reading %s", fname);

  /* forward table rules reference servers, so have to blow 
     them away */
  for (i=0; i<FTABSIZ; i++)
    ftab[i].new_id = 0;
  
  /* delete existing ones */
  if (last_server)
    {
      struct server *s = last_server;
      while (1)
	{
	  struct server *tmp = s->next;
	  free(s);
	  if (tmp == last_server)
	    break;
	  s = tmp;
	}
      last_server = NULL;
    }
	
  while ((line = fgets(buff, MAXLIN, f)))
    {
      struct in_addr addr;
      char *token = strtok(line, " \t\n");
      struct server *serv;
      struct irec *iface;

      if (!token || strcmp(token, "nameserver") != 0)
	continue;
      if (!(token = strtok(NULL, " \t\n")) || !inet_aton(token, &addr))
	continue;
      
      /* Avoid loops back to ourself */
      if (port == NAMESERVER_PORT)
	{
	  for (iface = interfaces; iface; iface = iface->next)
	    if (addr.s_addr == iface->addr.sin_addr.s_addr)
	      {
		syslog(LOG_WARNING, "ignoring nameserver %s - local interface",
		       inet_ntoa(addr));
		break;
	      }
	  if (iface)
	    continue;
	}

      if (!(serv = (struct server *)malloc(sizeof (struct server))))
	continue;

      if (last_server)
	last_server->next = serv;
      else
	last_server = serv;
      
      serv->next = last_server;
      last_server = serv;

      serv->addr.sin_family = AF_INET;
      serv->addr.sin_port = htons(NAMESERVER_PORT);
      serv->addr.sin_addr = addr;
      syslog(LOG_INFO, "using nameserver %s", inet_ntoa(addr)); 
    }
  
  fclose(f);
}
	
static void forward_query(int udpfd,
			  int peerfd,
			  struct sockaddr *udpaddr, 
			  HEADER *header,
			  int plen)
{
  time_t now = time(NULL);
  struct frec *forward;
  
   /* may be no available servers or recursion not speced */
  if (!last_server || !header->rd)
    forward = NULL;
  else if ((forward = lookup_frec_by_sender(ntohs(header->id), udpaddr)))
    {
      /* retry on existing query, send to next server */
      forward->sentto = forward->sentto->next;
      header->id = htons(forward->new_id);
    }
  else
    {
      /* new query, pick nameserver and send */
      forward = get_new_frec(now);
      forward->source = *udpaddr;
      forward->new_id = get_id();
      forward->fd = udpfd;
      forward->orig_id = ntohs(header->id);
      header->id = htons(forward->new_id);
      forward->sentto = last_server;
      last_server = last_server->next;
    }

  /* check for sendto errors here (no route to host) 
     if we fail to send to all nameservers, send back an error
     packet straight away (helps modem users when offline) */
  
  if (forward)
    {
      struct server *firstsentto = forward->sentto;
      while (1)
	{ 
	  if (sendto(peerfd, (char *)header, plen, 0, 
		     (struct sockaddr *)&forward->sentto->addr, 
		     sizeof(forward->sentto->addr)) != -1)
	    return;
	  
	  forward->sentto = forward->sentto->next;
	  /* check if we tried all without success */
	  if (forward->sentto == firstsentto)
	    break;
	}
      
      /* could not send on, prepare to return */ 
      header->id = htons(forward->orig_id);
      forward->new_id = 0; /* cancel */
    }	  
  
  /* could not send on, return empty answer */
  header->qr = 1; /* response */
  header->aa = 0; /* authoritive - never */
  header->ra = 1; /* recursion if available */
  header->tc = 0; /* not truncated */
  header->rcode = NOERROR; /* no error */
  header->ancount = htons(0); /* no answers */
  header->nscount = htons(0);
  header->arcount = htons(0);
  sendto(udpfd, (char *)header, plen, 0, 
	 udpaddr, sizeof(struct sockaddr));
}

static struct frec *get_new_frec(time_t now)
{
  int i;
  struct frec *oldest = &ftab[0];
  time_t oldtime = now;

  for(i=0; i<FTABSIZ; i++)
    {
      struct frec *f = &ftab[i];
      if (f->time <= oldtime)
	{
	  oldtime = f->time;
	  oldest = f;
	}
      if (f->new_id == 0)
	{
	  f->time = now;
	  return f;
	}
    }

  /* table full, use oldest */

  oldest->time = now;
  return oldest;
}
 
static struct frec *lookup_frec(unsigned short id)
{
  int i;
  for(i=0; i<FTABSIZ; i++)
    {
      struct frec *f = &ftab[i];
      if (f->new_id == id)
	return f;
    }
  return NULL;
}

static struct frec *lookup_frec_by_sender(unsigned short id,
					  struct sockaddr *addr)
{
  int i;
  for(i=0; i<FTABSIZ; i++)
    {
      struct frec *f = &ftab[i];
      if (f->new_id &&
	  f->orig_id == id && 
	  memcmp(&f->source, addr, sizeof(f->source)) == 0)
	return f;
    }
  return NULL;
}


/* return unique ids between 1 and 65535 */
/* These are now random, FSVO random, to frustrate DNS spoofers */
/* code adapted from glibc-2.1.3 */ 
static unsigned short get_id(void)
{
  struct timeval now;
  static int salt = 0;
  unsigned short ret = 0;

  /* salt stops us spinning wasting cpu on a host with
     a low resolution clock and avoids sending requests
     with the same id which are close in time. */

  while (ret == 0)
    {
      gettimeofday(&now, NULL);
      ret = salt-- ^ now.tv_sec ^ now.tv_usec ^ getpid();
      
      /* scrap ids already in use */
      if ((ret != 0) && lookup_frec(ret))
	ret = 0;
    }

  return ret;
}





