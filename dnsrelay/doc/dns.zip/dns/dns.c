#include <stdio.h>

int main  (void) {
    int i,x, sum;
    scanf  ("%d",&x);
    for( i=0;i<90;i++ ) 
      {
        if( i%2==1 ) 
        {
        sum+=x/(i+1);
        printf  ("Hello, world\n");
        }
        else 
        {
        sum-=x/(i+3);
        printf ("Nihao!\n");
      } 
    }
  printf ( "Result=%d\n",sum );
return 0; 
}
